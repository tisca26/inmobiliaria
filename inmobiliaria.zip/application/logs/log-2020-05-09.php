<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>


INFO - 2020-05-09 18:01:07 --> Config Class Initialized
INFO - 2020-05-09 18:01:07 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:01:07 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:01:07 --> Utf8 Class Initialized
INFO - 2020-05-09 18:01:07 --> URI Class Initialized
DEBUG - 2020-05-09 18:01:07 --> No URI present. Default controller set.
INFO - 2020-05-09 18:01:07 --> Router Class Initialized
INFO - 2020-05-09 18:01:07 --> Output Class Initialized
INFO - 2020-05-09 18:01:07 --> Security Class Initialized
DEBUG - 2020-05-09 18:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:01:07 --> Input Class Initialized
DEBUG - 2020-05-09 18:01:07 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:01:07 --> Loader Class Initialized
INFO - 2020-05-09 18:01:07 --> Helper loaded: language_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: url_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: html_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: form_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: util_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: session_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:01:07 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:01:07 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:01:07 --> Session: Class initialized using 'files' driver.
ERROR - 2020-05-09 18:01:07 --> Unable to load the requested class: Encrypt
INFO - 2020-05-09 18:04:45 --> Config Class Initialized
INFO - 2020-05-09 18:04:45 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:04:45 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:04:45 --> Utf8 Class Initialized
INFO - 2020-05-09 18:04:45 --> URI Class Initialized
DEBUG - 2020-05-09 18:04:45 --> No URI present. Default controller set.
INFO - 2020-05-09 18:04:45 --> Router Class Initialized
INFO - 2020-05-09 18:04:45 --> Output Class Initialized
INFO - 2020-05-09 18:04:45 --> Security Class Initialized
DEBUG - 2020-05-09 18:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:04:45 --> Input Class Initialized
DEBUG - 2020-05-09 18:04:45 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:04:45 --> Loader Class Initialized
INFO - 2020-05-09 18:04:45 --> Helper loaded: language_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: url_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: html_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: form_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: util_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: session_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:04:45 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:04:45 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-05-09 18:04:45 --> Controller Class Initialized
INFO - 2020-05-09 18:04:45 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:04:45 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:04:46 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:04:46 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:04:46 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:04:46 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:04:46 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
DEBUG - 2020-05-09 18:04:46 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:04:46 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:04:46 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:04:46 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:04:46 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:04:46 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:04:46 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:04:47 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:04:47 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\inicio/inicio_index.php
INFO - 2020-05-09 18:04:47 --> Final output sent to browser
DEBUG - 2020-05-09 18:04:47 --> Total execution time: 1.6342
INFO - 2020-05-09 18:05:00 --> Config Class Initialized
INFO - 2020-05-09 18:05:00 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:05:01 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:05:01 --> Utf8 Class Initialized
INFO - 2020-05-09 18:05:01 --> URI Class Initialized
INFO - 2020-05-09 18:05:01 --> Router Class Initialized
INFO - 2020-05-09 18:05:01 --> Output Class Initialized
INFO - 2020-05-09 18:05:01 --> Security Class Initialized
DEBUG - 2020-05-09 18:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:05:01 --> Input Class Initialized
DEBUG - 2020-05-09 18:05:01 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:05:01 --> Loader Class Initialized
INFO - 2020-05-09 18:05:01 --> Helper loaded: language_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: url_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: html_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: form_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: util_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: session_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:05:01 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:05:01 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-05-09 18:05:01 --> Controller Class Initialized
INFO - 2020-05-09 18:05:01 --> Language file loaded: language/spanish/propiedades/propiedades_index_lang.php
INFO - 2020-05-09 18:05:01 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:05:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2020-05-09 18:05:01 --> Pagination Class Initialized
INFO - 2020-05-09 18:05:01 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:05:01 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:05:01 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
DEBUG - 2020-05-09 18:05:01 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:05:01 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:05:01 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:05:01 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:05:01 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:05:01 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:05:01 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:05:01 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:05:01 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\propiedades/propiedades_index.php
INFO - 2020-05-09 18:05:01 --> Final output sent to browser
DEBUG - 2020-05-09 18:05:01 --> Total execution time: 0.9977
INFO - 2020-05-09 18:05:29 --> Config Class Initialized
INFO - 2020-05-09 18:05:29 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:05:29 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:05:29 --> Utf8 Class Initialized
INFO - 2020-05-09 18:05:29 --> URI Class Initialized
INFO - 2020-05-09 18:05:29 --> Router Class Initialized
INFO - 2020-05-09 18:05:29 --> Output Class Initialized
INFO - 2020-05-09 18:05:29 --> Security Class Initialized
DEBUG - 2020-05-09 18:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:05:29 --> Input Class Initialized
DEBUG - 2020-05-09 18:05:29 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:05:29 --> 404 Page Not Found: Propiedades/admin
INFO - 2020-05-09 18:05:35 --> Config Class Initialized
INFO - 2020-05-09 18:05:35 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:05:35 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:05:35 --> Utf8 Class Initialized
INFO - 2020-05-09 18:05:35 --> URI Class Initialized
INFO - 2020-05-09 18:05:35 --> Router Class Initialized
INFO - 2020-05-09 18:05:35 --> Output Class Initialized
INFO - 2020-05-09 18:05:35 --> Security Class Initialized
DEBUG - 2020-05-09 18:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:05:35 --> Input Class Initialized
DEBUG - 2020-05-09 18:05:35 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:05:35 --> 404 Page Not Found: Admin/index
INFO - 2020-05-09 18:05:39 --> Config Class Initialized
INFO - 2020-05-09 18:05:39 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:05:39 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:05:39 --> Utf8 Class Initialized
INFO - 2020-05-09 18:05:39 --> URI Class Initialized
INFO - 2020-05-09 18:05:39 --> Router Class Initialized
INFO - 2020-05-09 18:05:39 --> Output Class Initialized
INFO - 2020-05-09 18:05:39 --> Security Class Initialized
DEBUG - 2020-05-09 18:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:05:39 --> Input Class Initialized
DEBUG - 2020-05-09 18:05:39 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:05:39 --> 404 Page Not Found: Admin/index
INFO - 2020-05-09 18:05:48 --> Config Class Initialized
INFO - 2020-05-09 18:05:48 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:05:48 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:05:48 --> Utf8 Class Initialized
INFO - 2020-05-09 18:05:48 --> URI Class Initialized
INFO - 2020-05-09 18:05:48 --> Router Class Initialized
INFO - 2020-05-09 18:05:48 --> Output Class Initialized
INFO - 2020-05-09 18:05:48 --> Security Class Initialized
DEBUG - 2020-05-09 18:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:05:48 --> Input Class Initialized
DEBUG - 2020-05-09 18:05:48 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:05:48 --> 404 Page Not Found: admon//index
INFO - 2020-05-09 18:05:58 --> Config Class Initialized
INFO - 2020-05-09 18:05:58 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:05:58 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:05:58 --> Utf8 Class Initialized
INFO - 2020-05-09 18:05:58 --> URI Class Initialized
INFO - 2020-05-09 18:05:58 --> Router Class Initialized
INFO - 2020-05-09 18:05:58 --> Output Class Initialized
INFO - 2020-05-09 18:05:58 --> Security Class Initialized
DEBUG - 2020-05-09 18:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:05:58 --> Input Class Initialized
DEBUG - 2020-05-09 18:05:58 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:05:58 --> 404 Page Not Found: admon//index
INFO - 2020-05-09 18:06:18 --> Config Class Initialized
INFO - 2020-05-09 18:06:18 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:06:18 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:06:18 --> Utf8 Class Initialized
INFO - 2020-05-09 18:06:18 --> URI Class Initialized
INFO - 2020-05-09 18:06:18 --> Router Class Initialized
INFO - 2020-05-09 18:06:18 --> Output Class Initialized
INFO - 2020-05-09 18:06:18 --> Security Class Initialized
DEBUG - 2020-05-09 18:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:06:18 --> Input Class Initialized
DEBUG - 2020-05-09 18:06:18 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:06:19 --> Loader Class Initialized
INFO - 2020-05-09 18:06:19 --> Helper loaded: language_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: url_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: html_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: form_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: util_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: session_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:06:19 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:06:19 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-05-09 18:06:19 --> Controller Class Initialized
INFO - 2020-05-09 18:06:19 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/login/login_index.php
INFO - 2020-05-09 18:06:19 --> Final output sent to browser
DEBUG - 2020-05-09 18:06:19 --> Total execution time: 0.3957
INFO - 2020-05-09 18:06:25 --> Config Class Initialized
INFO - 2020-05-09 18:06:25 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:06:25 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:06:25 --> Utf8 Class Initialized
INFO - 2020-05-09 18:06:25 --> URI Class Initialized
INFO - 2020-05-09 18:06:25 --> Router Class Initialized
INFO - 2020-05-09 18:06:25 --> Output Class Initialized
INFO - 2020-05-09 18:06:25 --> Security Class Initialized
DEBUG - 2020-05-09 18:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:06:25 --> Input Class Initialized
DEBUG - 2020-05-09 18:06:25 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:06:25 --> Loader Class Initialized
INFO - 2020-05-09 18:06:25 --> Helper loaded: language_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: url_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: html_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: form_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: util_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: session_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:06:25 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:06:25 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-05-09 18:06:25 --> Controller Class Initialized
INFO - 2020-05-09 18:06:25 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/login/login_index.php
INFO - 2020-05-09 18:06:25 --> Final output sent to browser
DEBUG - 2020-05-09 18:06:25 --> Total execution time: 0.3599
INFO - 2020-05-09 18:10:06 --> Config Class Initialized
INFO - 2020-05-09 18:10:06 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:10:06 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:10:06 --> Utf8 Class Initialized
INFO - 2020-05-09 18:10:06 --> URI Class Initialized
INFO - 2020-05-09 18:10:06 --> Router Class Initialized
INFO - 2020-05-09 18:10:06 --> Output Class Initialized
INFO - 2020-05-09 18:10:06 --> Security Class Initialized
DEBUG - 2020-05-09 18:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:10:06 --> Input Class Initialized
DEBUG - 2020-05-09 18:10:06 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:10:06 --> Loader Class Initialized
INFO - 2020-05-09 18:10:06 --> Helper loaded: language_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: url_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: html_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: form_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: util_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: session_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:10:06 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:10:06 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-05-09 18:10:06 --> Controller Class Initialized
ERROR - 2020-05-09 18:10:06 --> Severity: Notice --> Undefined property: Login::$encrypt C:\xampp\htdocs\inmobiliaria\application\helpers\session_helper.php 20
ERROR - 2020-05-09 18:10:07 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\inmobiliaria\application\helpers\session_helper.php 20
INFO - 2020-05-09 18:13:11 --> Config Class Initialized
INFO - 2020-05-09 18:13:11 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:13:11 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:13:11 --> Utf8 Class Initialized
INFO - 2020-05-09 18:13:12 --> URI Class Initialized
INFO - 2020-05-09 18:13:12 --> Router Class Initialized
INFO - 2020-05-09 18:13:12 --> Output Class Initialized
INFO - 2020-05-09 18:13:12 --> Security Class Initialized
DEBUG - 2020-05-09 18:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:13:12 --> Input Class Initialized
DEBUG - 2020-05-09 18:13:12 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:13:12 --> Loader Class Initialized
INFO - 2020-05-09 18:13:12 --> Helper loaded: language_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: url_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: html_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: form_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: util_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: session_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:13:12 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:13:12 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:13:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:13:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:13:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:13:12 --> Encryption Class Initialized
INFO - 2020-05-09 18:13:12 --> Controller Class Initialized
ERROR - 2020-05-09 18:13:12 --> Severity: error --> Exception: Call to undefined method CI_Encryption::encode() C:\xampp\htdocs\inmobiliaria\application\helpers\session_helper.php 20
INFO - 2020-05-09 18:13:54 --> Config Class Initialized
INFO - 2020-05-09 18:13:54 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:13:54 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:13:54 --> Utf8 Class Initialized
INFO - 2020-05-09 18:13:54 --> URI Class Initialized
INFO - 2020-05-09 18:13:54 --> Router Class Initialized
INFO - 2020-05-09 18:13:54 --> Output Class Initialized
INFO - 2020-05-09 18:13:54 --> Security Class Initialized
DEBUG - 2020-05-09 18:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:13:54 --> Input Class Initialized
DEBUG - 2020-05-09 18:13:54 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:13:54 --> Loader Class Initialized
INFO - 2020-05-09 18:13:54 --> Helper loaded: language_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: url_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: html_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: form_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: util_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: session_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:13:54 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:13:54 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:13:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:13:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:13:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:13:54 --> Encryption Class Initialized
INFO - 2020-05-09 18:13:54 --> Controller Class Initialized
INFO - 2020-05-09 18:13:55 --> Config Class Initialized
INFO - 2020-05-09 18:13:55 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:13:55 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:13:55 --> Utf8 Class Initialized
INFO - 2020-05-09 18:13:55 --> URI Class Initialized
INFO - 2020-05-09 18:13:55 --> Router Class Initialized
INFO - 2020-05-09 18:13:55 --> Output Class Initialized
INFO - 2020-05-09 18:13:55 --> Security Class Initialized
DEBUG - 2020-05-09 18:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:13:55 --> Input Class Initialized
DEBUG - 2020-05-09 18:13:55 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:13:55 --> Loader Class Initialized
INFO - 2020-05-09 18:13:55 --> Helper loaded: language_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: url_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: html_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: form_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: util_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: session_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:13:55 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:13:55 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:13:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:13:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:13:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:13:55 --> Encryption Class Initialized
INFO - 2020-05-09 18:13:55 --> Controller Class Initialized
INFO - 2020-05-09 18:13:55 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:13:55 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:13:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:13:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:13:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_index.php
INFO - 2020-05-09 18:13:55 --> Final output sent to browser
DEBUG - 2020-05-09 18:13:55 --> Total execution time: 0.5176
INFO - 2020-05-09 18:14:02 --> Config Class Initialized
INFO - 2020-05-09 18:14:02 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:14:02 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:14:02 --> Utf8 Class Initialized
INFO - 2020-05-09 18:14:02 --> URI Class Initialized
INFO - 2020-05-09 18:14:02 --> Router Class Initialized
INFO - 2020-05-09 18:14:02 --> Output Class Initialized
INFO - 2020-05-09 18:14:02 --> Security Class Initialized
DEBUG - 2020-05-09 18:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:14:02 --> Input Class Initialized
DEBUG - 2020-05-09 18:14:02 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:14:02 --> Loader Class Initialized
INFO - 2020-05-09 18:14:02 --> Helper loaded: language_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: url_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: html_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: form_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: util_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: session_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:14:02 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:14:02 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:14:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:14:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:14:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:14:02 --> Encryption Class Initialized
INFO - 2020-05-09 18:14:02 --> Controller Class Initialized
INFO - 2020-05-09 18:14:02 --> Model "Usuarios_model" initialized
INFO - 2020-05-09 18:14:03 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:14:03 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:14:03 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:14:03 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/usuarios/usuarios_index.php
INFO - 2020-05-09 18:14:03 --> Final output sent to browser
DEBUG - 2020-05-09 18:14:03 --> Total execution time: 0.7018
INFO - 2020-05-09 18:14:05 --> Config Class Initialized
INFO - 2020-05-09 18:14:05 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:14:05 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:14:05 --> Utf8 Class Initialized
INFO - 2020-05-09 18:14:05 --> URI Class Initialized
INFO - 2020-05-09 18:14:05 --> Router Class Initialized
INFO - 2020-05-09 18:14:05 --> Output Class Initialized
INFO - 2020-05-09 18:14:05 --> Security Class Initialized
DEBUG - 2020-05-09 18:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:14:05 --> Input Class Initialized
DEBUG - 2020-05-09 18:14:05 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:14:05 --> Loader Class Initialized
INFO - 2020-05-09 18:14:05 --> Helper loaded: language_helper
INFO - 2020-05-09 18:14:05 --> Helper loaded: url_helper
INFO - 2020-05-09 18:14:05 --> Helper loaded: html_helper
INFO - 2020-05-09 18:14:05 --> Helper loaded: form_helper
INFO - 2020-05-09 18:14:05 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:14:06 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:14:06 --> Helper loaded: util_helper
INFO - 2020-05-09 18:14:06 --> Helper loaded: session_helper
INFO - 2020-05-09 18:14:06 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:14:06 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:14:06 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:14:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:14:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:14:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:14:06 --> Encryption Class Initialized
INFO - 2020-05-09 18:14:06 --> Controller Class Initialized
INFO - 2020-05-09 18:14:06 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:14:06 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:14:06 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:14:06 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:14:06 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_index.php
INFO - 2020-05-09 18:14:06 --> Final output sent to browser
DEBUG - 2020-05-09 18:14:06 --> Total execution time: 0.3992
INFO - 2020-05-09 18:14:07 --> Config Class Initialized
INFO - 2020-05-09 18:14:07 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:14:07 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:14:07 --> Utf8 Class Initialized
INFO - 2020-05-09 18:14:07 --> URI Class Initialized
INFO - 2020-05-09 18:14:07 --> Router Class Initialized
INFO - 2020-05-09 18:14:07 --> Output Class Initialized
INFO - 2020-05-09 18:14:08 --> Security Class Initialized
DEBUG - 2020-05-09 18:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:14:08 --> Input Class Initialized
DEBUG - 2020-05-09 18:14:08 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:14:08 --> Loader Class Initialized
INFO - 2020-05-09 18:14:08 --> Helper loaded: language_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: url_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: html_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: form_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: util_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: session_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:14:08 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:14:08 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:14:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:14:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:14:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:14:08 --> Encryption Class Initialized
INFO - 2020-05-09 18:14:08 --> Controller Class Initialized
INFO - 2020-05-09 18:14:08 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:14:08 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:14:08 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:14:08 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:14:08 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 18:14:08 --> Final output sent to browser
DEBUG - 2020-05-09 18:14:08 --> Total execution time: 0.5924
INFO - 2020-05-09 18:14:59 --> Config Class Initialized
INFO - 2020-05-09 18:14:59 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:14:59 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:14:59 --> Utf8 Class Initialized
INFO - 2020-05-09 18:14:59 --> URI Class Initialized
INFO - 2020-05-09 18:14:59 --> Router Class Initialized
INFO - 2020-05-09 18:14:59 --> Output Class Initialized
INFO - 2020-05-09 18:14:59 --> Security Class Initialized
DEBUG - 2020-05-09 18:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:14:59 --> Input Class Initialized
DEBUG - 2020-05-09 18:14:59 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:14:59 --> 404 Page Not Found: admon/Carga_archivos/index
INFO - 2020-05-09 18:15:10 --> Config Class Initialized
INFO - 2020-05-09 18:15:10 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:15:10 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:15:10 --> Utf8 Class Initialized
INFO - 2020-05-09 18:15:10 --> URI Class Initialized
INFO - 2020-05-09 18:15:10 --> Router Class Initialized
INFO - 2020-05-09 18:15:10 --> Output Class Initialized
INFO - 2020-05-09 18:15:10 --> Security Class Initialized
DEBUG - 2020-05-09 18:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:15:10 --> Input Class Initialized
DEBUG - 2020-05-09 18:15:10 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:15:10 --> Loader Class Initialized
INFO - 2020-05-09 18:15:10 --> Helper loaded: language_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: url_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: html_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: form_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: util_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: session_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:15:10 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:15:10 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:15:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:15:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:15:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:15:10 --> Encryption Class Initialized
INFO - 2020-05-09 18:15:10 --> Controller Class Initialized
INFO - 2020-05-09 18:15:12 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\carga_archivos/carga_archivos_index.php
INFO - 2020-05-09 18:15:12 --> Final output sent to browser
DEBUG - 2020-05-09 18:15:12 --> Total execution time: 2.2965
INFO - 2020-05-09 18:15:26 --> Config Class Initialized
INFO - 2020-05-09 18:15:26 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:15:26 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:15:26 --> Utf8 Class Initialized
INFO - 2020-05-09 18:15:26 --> URI Class Initialized
DEBUG - 2020-05-09 18:15:26 --> No URI present. Default controller set.
INFO - 2020-05-09 18:15:26 --> Router Class Initialized
INFO - 2020-05-09 18:15:26 --> Output Class Initialized
INFO - 2020-05-09 18:15:26 --> Security Class Initialized
DEBUG - 2020-05-09 18:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:15:26 --> Input Class Initialized
DEBUG - 2020-05-09 18:15:26 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:15:26 --> Loader Class Initialized
INFO - 2020-05-09 18:15:26 --> Helper loaded: language_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: url_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: html_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: form_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: util_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: session_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:15:26 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:15:27 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:15:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:15:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:15:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:15:27 --> Encryption Class Initialized
INFO - 2020-05-09 18:15:27 --> Controller Class Initialized
INFO - 2020-05-09 18:15:27 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:15:27 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:15:27 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:15:27 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:15:27 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:15:27 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:15:27 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
DEBUG - 2020-05-09 18:15:27 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:15:27 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:15:27 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:15:27 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:15:27 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:15:27 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:15:27 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:15:27 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:15:27 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\inicio/inicio_index.php
INFO - 2020-05-09 18:15:27 --> Final output sent to browser
DEBUG - 2020-05-09 18:15:27 --> Total execution time: 0.6167
INFO - 2020-05-09 18:17:35 --> Config Class Initialized
INFO - 2020-05-09 18:17:35 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:17:35 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:17:35 --> Utf8 Class Initialized
INFO - 2020-05-09 18:17:35 --> URI Class Initialized
INFO - 2020-05-09 18:17:35 --> Router Class Initialized
INFO - 2020-05-09 18:17:35 --> Output Class Initialized
INFO - 2020-05-09 18:17:35 --> Security Class Initialized
DEBUG - 2020-05-09 18:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:17:35 --> Input Class Initialized
DEBUG - 2020-05-09 18:17:35 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:17:35 --> 404 Page Not Found: Carga_propiedades/index
INFO - 2020-05-09 18:17:44 --> Config Class Initialized
INFO - 2020-05-09 18:17:44 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:17:44 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:17:44 --> Utf8 Class Initialized
INFO - 2020-05-09 18:17:44 --> URI Class Initialized
INFO - 2020-05-09 18:17:44 --> Router Class Initialized
INFO - 2020-05-09 18:17:44 --> Output Class Initialized
INFO - 2020-05-09 18:17:44 --> Security Class Initialized
DEBUG - 2020-05-09 18:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:17:45 --> Input Class Initialized
DEBUG - 2020-05-09 18:17:45 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:17:45 --> Loader Class Initialized
INFO - 2020-05-09 18:17:45 --> Helper loaded: language_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: url_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: html_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: form_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: util_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: session_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:17:45 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:17:45 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:17:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:17:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:17:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:17:45 --> Encryption Class Initialized
INFO - 2020-05-09 18:17:45 --> Controller Class Initialized
INFO - 2020-05-09 18:17:45 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:17:45 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:17:45 --> Model "Estatus_propiedades_model" initialized
INFO - 2020-05-09 18:17:46 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\carga_archivos/carga_archivos_index.php
INFO - 2020-05-09 18:17:46 --> Final output sent to browser
DEBUG - 2020-05-09 18:17:46 --> Total execution time: 1.6119
INFO - 2020-05-09 18:17:51 --> Config Class Initialized
INFO - 2020-05-09 18:17:51 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:17:51 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:17:51 --> Utf8 Class Initialized
INFO - 2020-05-09 18:17:51 --> URI Class Initialized
DEBUG - 2020-05-09 18:17:51 --> No URI present. Default controller set.
INFO - 2020-05-09 18:17:51 --> Router Class Initialized
INFO - 2020-05-09 18:17:51 --> Output Class Initialized
INFO - 2020-05-09 18:17:51 --> Security Class Initialized
DEBUG - 2020-05-09 18:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:17:51 --> Input Class Initialized
DEBUG - 2020-05-09 18:17:51 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:17:51 --> Loader Class Initialized
INFO - 2020-05-09 18:17:51 --> Helper loaded: language_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: url_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: html_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: form_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: util_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: session_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:17:51 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:17:51 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:17:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:17:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:17:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:17:51 --> Encryption Class Initialized
INFO - 2020-05-09 18:17:51 --> Controller Class Initialized
INFO - 2020-05-09 18:17:51 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:17:51 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:17:51 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:17:51 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:17:51 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:17:51 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:17:51 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
DEBUG - 2020-05-09 18:17:51 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:17:51 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:17:51 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:17:51 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:17:51 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:17:51 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:17:51 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:17:51 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:17:51 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\inicio/inicio_index.php
INFO - 2020-05-09 18:17:51 --> Final output sent to browser
DEBUG - 2020-05-09 18:17:51 --> Total execution time: 0.6941
INFO - 2020-05-09 18:18:17 --> Config Class Initialized
INFO - 2020-05-09 18:18:17 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:18:17 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:18:17 --> Utf8 Class Initialized
INFO - 2020-05-09 18:18:17 --> URI Class Initialized
INFO - 2020-05-09 18:18:17 --> Router Class Initialized
INFO - 2020-05-09 18:18:17 --> Output Class Initialized
INFO - 2020-05-09 18:18:17 --> Security Class Initialized
DEBUG - 2020-05-09 18:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:18:17 --> Input Class Initialized
DEBUG - 2020-05-09 18:18:17 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:18:17 --> Loader Class Initialized
INFO - 2020-05-09 18:18:17 --> Helper loaded: language_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: url_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: html_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: form_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: util_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: session_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:18:17 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:18:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:18:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:18:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:18:17 --> Encryption Class Initialized
INFO - 2020-05-09 18:18:17 --> Controller Class Initialized
INFO - 2020-05-09 18:18:17 --> Config Class Initialized
INFO - 2020-05-09 18:18:17 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:18:17 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:18:17 --> Utf8 Class Initialized
INFO - 2020-05-09 18:18:17 --> URI Class Initialized
INFO - 2020-05-09 18:18:17 --> Router Class Initialized
INFO - 2020-05-09 18:18:17 --> Output Class Initialized
INFO - 2020-05-09 18:18:17 --> Security Class Initialized
DEBUG - 2020-05-09 18:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:18:17 --> Input Class Initialized
DEBUG - 2020-05-09 18:18:17 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:18:17 --> Loader Class Initialized
INFO - 2020-05-09 18:18:17 --> Helper loaded: language_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: url_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: html_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: form_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: util_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: session_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:18:17 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:18:17 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:18:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:18:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:18:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:18:17 --> Encryption Class Initialized
INFO - 2020-05-09 18:18:17 --> Controller Class Initialized
INFO - 2020-05-09 18:18:17 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:18:17 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:18:17 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:18:17 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:18:17 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_index.php
INFO - 2020-05-09 18:18:17 --> Final output sent to browser
DEBUG - 2020-05-09 18:18:17 --> Total execution time: 0.4188
INFO - 2020-05-09 18:18:20 --> Config Class Initialized
INFO - 2020-05-09 18:18:20 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:18:20 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:18:20 --> Utf8 Class Initialized
INFO - 2020-05-09 18:18:20 --> URI Class Initialized
INFO - 2020-05-09 18:18:20 --> Router Class Initialized
INFO - 2020-05-09 18:18:20 --> Output Class Initialized
INFO - 2020-05-09 18:18:20 --> Security Class Initialized
DEBUG - 2020-05-09 18:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:18:20 --> Input Class Initialized
DEBUG - 2020-05-09 18:18:20 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:18:20 --> Loader Class Initialized
INFO - 2020-05-09 18:18:20 --> Helper loaded: language_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: url_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: html_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: form_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: util_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: session_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:18:20 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:18:21 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:18:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:18:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:18:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:18:21 --> Encryption Class Initialized
INFO - 2020-05-09 18:18:21 --> Controller Class Initialized
INFO - 2020-05-09 18:18:21 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:18:21 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:18:21 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:18:21 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:18:21 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 18:18:21 --> Final output sent to browser
DEBUG - 2020-05-09 18:18:21 --> Total execution time: 0.5207
INFO - 2020-05-09 18:18:29 --> Config Class Initialized
INFO - 2020-05-09 18:18:29 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:18:29 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:18:29 --> Utf8 Class Initialized
INFO - 2020-05-09 18:18:29 --> URI Class Initialized
INFO - 2020-05-09 18:18:29 --> Router Class Initialized
INFO - 2020-05-09 18:18:29 --> Output Class Initialized
INFO - 2020-05-09 18:18:29 --> Security Class Initialized
DEBUG - 2020-05-09 18:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:18:29 --> Input Class Initialized
DEBUG - 2020-05-09 18:18:29 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:18:29 --> Loader Class Initialized
INFO - 2020-05-09 18:18:29 --> Helper loaded: language_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: url_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: html_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: form_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: util_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: session_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:18:29 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:18:29 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:18:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:18:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:18:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:18:29 --> Encryption Class Initialized
INFO - 2020-05-09 18:18:29 --> Controller Class Initialized
INFO - 2020-05-09 18:18:29 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:18:29 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:18:30 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:18:30 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:18:30 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:18:30 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_editar.php
INFO - 2020-05-09 18:18:30 --> Final output sent to browser
DEBUG - 2020-05-09 18:18:30 --> Total execution time: 0.7075
INFO - 2020-05-09 18:18:37 --> Config Class Initialized
INFO - 2020-05-09 18:18:37 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:18:37 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:18:37 --> Utf8 Class Initialized
INFO - 2020-05-09 18:18:37 --> URI Class Initialized
INFO - 2020-05-09 18:18:37 --> Router Class Initialized
INFO - 2020-05-09 18:18:37 --> Output Class Initialized
INFO - 2020-05-09 18:18:37 --> Security Class Initialized
DEBUG - 2020-05-09 18:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:18:37 --> Input Class Initialized
DEBUG - 2020-05-09 18:18:37 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:18:37 --> Loader Class Initialized
INFO - 2020-05-09 18:18:37 --> Helper loaded: language_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: url_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: html_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: form_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: util_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: session_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:18:37 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:18:37 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:18:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:18:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:18:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:18:37 --> Encryption Class Initialized
INFO - 2020-05-09 18:18:37 --> Controller Class Initialized
INFO - 2020-05-09 18:18:37 --> Form Validation Class Initialized
INFO - 2020-05-09 18:18:37 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2020-05-09 18:18:37 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:18:37 --> Upload Class Initialized
DEBUG - 2020-05-09 18:18:37 --> Si sube imagen con nombre: 
INFO - 2020-05-09 18:18:37 --> Language file loaded: language/spanish/upload_lang.php
DEBUG - 2020-05-09 18:18:37 --> No seleccionaste un archivo para subir.
INFO - 2020-05-09 18:18:37 --> Model "Estatus_propiedades_model" initialized
INFO - 2020-05-09 18:18:38 --> Config Class Initialized
INFO - 2020-05-09 18:18:38 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:18:38 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:18:38 --> Utf8 Class Initialized
INFO - 2020-05-09 18:18:38 --> URI Class Initialized
INFO - 2020-05-09 18:18:38 --> Router Class Initialized
INFO - 2020-05-09 18:18:38 --> Output Class Initialized
INFO - 2020-05-09 18:18:38 --> Security Class Initialized
DEBUG - 2020-05-09 18:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:18:38 --> Input Class Initialized
DEBUG - 2020-05-09 18:18:38 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:18:38 --> Loader Class Initialized
INFO - 2020-05-09 18:18:38 --> Helper loaded: language_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: url_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: html_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: form_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: util_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: session_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:18:38 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:18:38 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:18:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:18:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:18:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:18:38 --> Encryption Class Initialized
INFO - 2020-05-09 18:18:38 --> Controller Class Initialized
INFO - 2020-05-09 18:18:38 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:18:38 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:18:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:18:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:18:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 18:18:38 --> Final output sent to browser
DEBUG - 2020-05-09 18:18:38 --> Total execution time: 0.5460
INFO - 2020-05-09 18:18:41 --> Config Class Initialized
INFO - 2020-05-09 18:18:41 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:18:41 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:18:41 --> Utf8 Class Initialized
INFO - 2020-05-09 18:18:41 --> URI Class Initialized
DEBUG - 2020-05-09 18:18:41 --> No URI present. Default controller set.
INFO - 2020-05-09 18:18:41 --> Router Class Initialized
INFO - 2020-05-09 18:18:41 --> Output Class Initialized
INFO - 2020-05-09 18:18:41 --> Security Class Initialized
DEBUG - 2020-05-09 18:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:18:41 --> Input Class Initialized
DEBUG - 2020-05-09 18:18:41 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:18:41 --> Loader Class Initialized
INFO - 2020-05-09 18:18:41 --> Helper loaded: language_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: url_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: html_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: form_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: util_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: session_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:18:41 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:18:41 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:18:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:18:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:18:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:18:41 --> Encryption Class Initialized
INFO - 2020-05-09 18:18:41 --> Controller Class Initialized
INFO - 2020-05-09 18:18:41 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:18:41 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:18:41 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:18:42 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:18:42 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:18:42 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:18:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
ERROR - 2020-05-09 18:18:42 --> Could not find the language line "Venta"
DEBUG - 2020-05-09 18:18:42 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:18:42 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:18:42 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:18:42 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:18:42 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:18:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:18:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:18:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:18:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\inicio/inicio_index.php
INFO - 2020-05-09 18:18:42 --> Final output sent to browser
DEBUG - 2020-05-09 18:18:42 --> Total execution time: 0.9518
INFO - 2020-05-09 18:49:36 --> Config Class Initialized
INFO - 2020-05-09 18:49:37 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:49:37 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:49:37 --> Utf8 Class Initialized
INFO - 2020-05-09 18:49:37 --> URI Class Initialized
INFO - 2020-05-09 18:49:37 --> Router Class Initialized
INFO - 2020-05-09 18:49:37 --> Output Class Initialized
INFO - 2020-05-09 18:49:37 --> Security Class Initialized
DEBUG - 2020-05-09 18:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:49:37 --> Input Class Initialized
DEBUG - 2020-05-09 18:49:37 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:49:38 --> Loader Class Initialized
INFO - 2020-05-09 18:49:38 --> Helper loaded: language_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: url_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: html_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: form_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: util_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: session_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:49:38 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:49:38 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:49:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:49:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:49:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:49:39 --> Encryption Class Initialized
INFO - 2020-05-09 18:49:39 --> Controller Class Initialized
INFO - 2020-05-09 18:49:39 --> Language file loaded: language/spanish/propiedades/propiedades_index_lang.php
INFO - 2020-05-09 18:49:39 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:49:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2020-05-09 18:49:39 --> Pagination Class Initialized
INFO - 2020-05-09 18:49:39 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:49:39 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:49:40 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
DEBUG - 2020-05-09 18:49:40 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:49:40 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:49:40 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:49:40 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:49:40 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:49:40 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:49:40 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:49:40 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:49:40 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\propiedades/propiedades_index.php
INFO - 2020-05-09 18:49:40 --> Final output sent to browser
DEBUG - 2020-05-09 18:49:40 --> Total execution time: 3.5089
INFO - 2020-05-09 18:49:52 --> Config Class Initialized
INFO - 2020-05-09 18:49:52 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:49:52 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:49:52 --> Utf8 Class Initialized
INFO - 2020-05-09 18:49:52 --> URI Class Initialized
INFO - 2020-05-09 18:49:52 --> Router Class Initialized
INFO - 2020-05-09 18:49:52 --> Output Class Initialized
INFO - 2020-05-09 18:49:52 --> Security Class Initialized
DEBUG - 2020-05-09 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:49:52 --> Input Class Initialized
DEBUG - 2020-05-09 18:49:52 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:49:52 --> Loader Class Initialized
INFO - 2020-05-09 18:49:52 --> Helper loaded: language_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: url_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: html_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: form_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: util_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: session_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:49:52 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:49:52 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:49:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:49:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:49:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:49:52 --> Encryption Class Initialized
INFO - 2020-05-09 18:49:52 --> Controller Class Initialized
INFO - 2020-05-09 18:49:52 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:49:52 --> Language file loaded: language/spanish/agentes/agentes_index_lang.php
INFO - 2020-05-09 18:49:52 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:49:52 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:49:52 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:49:52 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:49:52 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
INFO - 2020-05-09 18:49:52 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:49:52 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:49:52 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:49:52 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:49:52 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:49:53 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:49:53 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\agentes/agentes_index.php
INFO - 2020-05-09 18:49:53 --> Final output sent to browser
DEBUG - 2020-05-09 18:49:53 --> Total execution time: 0.9751
INFO - 2020-05-09 18:50:01 --> Config Class Initialized
INFO - 2020-05-09 18:50:01 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:50:01 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:50:01 --> Utf8 Class Initialized
INFO - 2020-05-09 18:50:01 --> URI Class Initialized
INFO - 2020-05-09 18:50:01 --> Router Class Initialized
INFO - 2020-05-09 18:50:02 --> Output Class Initialized
INFO - 2020-05-09 18:50:02 --> Security Class Initialized
DEBUG - 2020-05-09 18:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:50:02 --> Input Class Initialized
DEBUG - 2020-05-09 18:50:02 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:50:02 --> Loader Class Initialized
INFO - 2020-05-09 18:50:02 --> Helper loaded: language_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: url_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: html_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: form_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: util_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: session_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:50:02 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:50:02 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:50:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:50:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:50:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:50:02 --> Encryption Class Initialized
INFO - 2020-05-09 18:50:02 --> Controller Class Initialized
INFO - 2020-05-09 18:50:02 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:50:02 --> Language file loaded: language/spanish/nosotros/nosotros_index_lang.php
INFO - 2020-05-09 18:50:02 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:50:02 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:50:02 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:50:02 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:50:02 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
INFO - 2020-05-09 18:50:02 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:50:02 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:50:02 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:50:02 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:50:03 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:50:03 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:50:03 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\nosotros/nosotros_index.php
INFO - 2020-05-09 18:50:03 --> Final output sent to browser
DEBUG - 2020-05-09 18:50:03 --> Total execution time: 1.2078
INFO - 2020-05-09 18:50:15 --> Config Class Initialized
INFO - 2020-05-09 18:50:15 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:50:15 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:50:15 --> Utf8 Class Initialized
INFO - 2020-05-09 18:50:15 --> URI Class Initialized
INFO - 2020-05-09 18:50:15 --> Router Class Initialized
INFO - 2020-05-09 18:50:15 --> Output Class Initialized
INFO - 2020-05-09 18:50:15 --> Security Class Initialized
DEBUG - 2020-05-09 18:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:50:15 --> Input Class Initialized
DEBUG - 2020-05-09 18:50:15 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:50:15 --> Loader Class Initialized
INFO - 2020-05-09 18:50:15 --> Helper loaded: language_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: url_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: html_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: form_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: util_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: session_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:50:15 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:50:15 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:50:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:50:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:50:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:50:15 --> Encryption Class Initialized
INFO - 2020-05-09 18:50:15 --> Controller Class Initialized
INFO - 2020-05-09 18:50:15 --> Language file loaded: language/spanish/contacto/contacto_index_lang.php
INFO - 2020-05-09 18:50:16 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:50:16 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:50:16 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:50:16 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:50:16 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
INFO - 2020-05-09 18:50:16 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:50:16 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:50:16 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:50:16 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:50:16 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:50:16 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:50:16 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\contacto/contacto_index.php
INFO - 2020-05-09 18:50:16 --> Final output sent to browser
DEBUG - 2020-05-09 18:50:16 --> Total execution time: 1.0651
INFO - 2020-05-09 18:50:37 --> Config Class Initialized
INFO - 2020-05-09 18:50:37 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:50:37 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:50:37 --> Utf8 Class Initialized
INFO - 2020-05-09 18:50:37 --> URI Class Initialized
INFO - 2020-05-09 18:50:37 --> Router Class Initialized
INFO - 2020-05-09 18:50:37 --> Output Class Initialized
INFO - 2020-05-09 18:50:37 --> Security Class Initialized
DEBUG - 2020-05-09 18:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:50:37 --> Input Class Initialized
DEBUG - 2020-05-09 18:50:37 --> ---- Loaded Language: english ----
INFO - 2020-05-09 18:50:37 --> Loader Class Initialized
INFO - 2020-05-09 18:50:37 --> Helper loaded: language_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: url_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: html_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: form_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: util_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: session_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:50:37 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:50:37 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:50:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:50:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:50:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:50:37 --> Encryption Class Initialized
INFO - 2020-05-09 18:50:37 --> Controller Class Initialized
INFO - 2020-05-09 18:50:37 --> Language file loaded: language/english/contacto/contacto_index_lang.php
INFO - 2020-05-09 18:50:37 --> Language file loaded: language/english/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:50:37 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:50:38 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 18:50:38 --> Could not find the language line "buscar"
INFO - 2020-05-09 18:50:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
INFO - 2020-05-09 18:50:38 --> Language file loaded: language/english/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:50:38 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:50:38 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:50:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:50:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:50:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:50:38 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\contacto/contacto_index.php
INFO - 2020-05-09 18:50:38 --> Final output sent to browser
DEBUG - 2020-05-09 18:50:38 --> Total execution time: 1.0610
INFO - 2020-05-09 18:50:43 --> Config Class Initialized
INFO - 2020-05-09 18:50:43 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:50:43 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:50:43 --> Utf8 Class Initialized
INFO - 2020-05-09 18:50:43 --> URI Class Initialized
INFO - 2020-05-09 18:50:43 --> Router Class Initialized
INFO - 2020-05-09 18:50:43 --> Output Class Initialized
INFO - 2020-05-09 18:50:43 --> Security Class Initialized
DEBUG - 2020-05-09 18:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:50:43 --> Input Class Initialized
DEBUG - 2020-05-09 18:50:43 --> ---- Loaded Language: english ----
INFO - 2020-05-09 18:50:43 --> Loader Class Initialized
INFO - 2020-05-09 18:50:43 --> Helper loaded: language_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: url_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: html_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: form_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: util_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: session_helper
INFO - 2020-05-09 18:50:43 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:50:44 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:50:44 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:50:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:50:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:50:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:50:44 --> Encryption Class Initialized
INFO - 2020-05-09 18:50:44 --> Controller Class Initialized
INFO - 2020-05-09 18:50:44 --> Language file loaded: language/english/propiedades/propiedades_index_lang.php
INFO - 2020-05-09 18:50:44 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-05-09 18:50:44 --> Pagination Class Initialized
INFO - 2020-05-09 18:50:44 --> Language file loaded: language/english/menus/menu_web_1_lang.php
INFO - 2020-05-09 18:50:44 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:50:44 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
DEBUG - 2020-05-09 18:50:44 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:50:44 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:50:44 --> Language file loaded: language/english/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 18:50:44 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 18:50:44 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 18:50:44 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 18:50:44 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 18:50:44 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 18:50:44 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\propiedades/propiedades_index.php
INFO - 2020-05-09 18:50:44 --> Final output sent to browser
DEBUG - 2020-05-09 18:50:44 --> Total execution time: 1.1455
INFO - 2020-05-09 18:51:04 --> Config Class Initialized
INFO - 2020-05-09 18:51:04 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:04 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:04 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:04 --> URI Class Initialized
INFO - 2020-05-09 18:51:04 --> Router Class Initialized
INFO - 2020-05-09 18:51:04 --> Output Class Initialized
INFO - 2020-05-09 18:51:04 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:04 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:04 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:04 --> Loader Class Initialized
INFO - 2020-05-09 18:51:04 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:04 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:04 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:04 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:05 --> Controller Class Initialized
INFO - 2020-05-09 18:51:05 --> Config Class Initialized
INFO - 2020-05-09 18:51:05 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:05 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:05 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:05 --> URI Class Initialized
INFO - 2020-05-09 18:51:05 --> Router Class Initialized
INFO - 2020-05-09 18:51:05 --> Output Class Initialized
INFO - 2020-05-09 18:51:05 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:05 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:05 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:05 --> Loader Class Initialized
INFO - 2020-05-09 18:51:05 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:05 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:05 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:05 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:05 --> Controller Class Initialized
INFO - 2020-05-09 18:51:05 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:51:05 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:51:05 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:51:05 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:51:05 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_index.php
INFO - 2020-05-09 18:51:05 --> Final output sent to browser
DEBUG - 2020-05-09 18:51:05 --> Total execution time: 0.8181
INFO - 2020-05-09 18:51:08 --> Config Class Initialized
INFO - 2020-05-09 18:51:08 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:08 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:08 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:08 --> URI Class Initialized
INFO - 2020-05-09 18:51:09 --> Router Class Initialized
INFO - 2020-05-09 18:51:09 --> Output Class Initialized
INFO - 2020-05-09 18:51:09 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:09 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:09 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:09 --> Loader Class Initialized
INFO - 2020-05-09 18:51:09 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:09 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:09 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:09 --> Controller Class Initialized
INFO - 2020-05-09 18:51:09 --> Config Class Initialized
INFO - 2020-05-09 18:51:09 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:09 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:09 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:09 --> URI Class Initialized
INFO - 2020-05-09 18:51:09 --> Router Class Initialized
INFO - 2020-05-09 18:51:09 --> Output Class Initialized
INFO - 2020-05-09 18:51:09 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:09 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:09 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:09 --> Loader Class Initialized
INFO - 2020-05-09 18:51:09 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:09 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:09 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:09 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:10 --> Controller Class Initialized
INFO - 2020-05-09 18:51:10 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/login/login_index.php
INFO - 2020-05-09 18:51:10 --> Final output sent to browser
DEBUG - 2020-05-09 18:51:10 --> Total execution time: 0.6055
INFO - 2020-05-09 18:51:17 --> Config Class Initialized
INFO - 2020-05-09 18:51:17 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:17 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:17 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:17 --> URI Class Initialized
INFO - 2020-05-09 18:51:17 --> Router Class Initialized
INFO - 2020-05-09 18:51:17 --> Output Class Initialized
INFO - 2020-05-09 18:51:17 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:17 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:17 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:17 --> Loader Class Initialized
INFO - 2020-05-09 18:51:17 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:17 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:17 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:17 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:17 --> Controller Class Initialized
INFO - 2020-05-09 18:51:17 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/login/login_index.php
INFO - 2020-05-09 18:51:17 --> Final output sent to browser
DEBUG - 2020-05-09 18:51:17 --> Total execution time: 0.6967
INFO - 2020-05-09 18:51:23 --> Config Class Initialized
INFO - 2020-05-09 18:51:23 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:23 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:23 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:23 --> URI Class Initialized
INFO - 2020-05-09 18:51:23 --> Router Class Initialized
INFO - 2020-05-09 18:51:23 --> Output Class Initialized
INFO - 2020-05-09 18:51:24 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:24 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:24 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:24 --> Loader Class Initialized
INFO - 2020-05-09 18:51:24 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:24 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:24 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:24 --> Controller Class Initialized
INFO - 2020-05-09 18:51:24 --> Config Class Initialized
INFO - 2020-05-09 18:51:24 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:24 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:24 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:24 --> URI Class Initialized
INFO - 2020-05-09 18:51:24 --> Router Class Initialized
INFO - 2020-05-09 18:51:24 --> Output Class Initialized
INFO - 2020-05-09 18:51:24 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:24 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:24 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:24 --> Loader Class Initialized
INFO - 2020-05-09 18:51:24 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:24 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:24 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:25 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:25 --> Controller Class Initialized
INFO - 2020-05-09 18:51:25 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:51:25 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:51:25 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:51:25 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:51:25 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_index.php
INFO - 2020-05-09 18:51:25 --> Final output sent to browser
DEBUG - 2020-05-09 18:51:25 --> Total execution time: 0.6065
INFO - 2020-05-09 18:51:34 --> Config Class Initialized
INFO - 2020-05-09 18:51:34 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:34 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:34 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:34 --> URI Class Initialized
INFO - 2020-05-09 18:51:34 --> Router Class Initialized
INFO - 2020-05-09 18:51:34 --> Output Class Initialized
INFO - 2020-05-09 18:51:34 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:34 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:34 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:34 --> Loader Class Initialized
INFO - 2020-05-09 18:51:34 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:34 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:35 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:35 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:35 --> Controller Class Initialized
INFO - 2020-05-09 18:51:35 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:51:35 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:51:35 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:51:35 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_insertar.php
INFO - 2020-05-09 18:51:35 --> Final output sent to browser
DEBUG - 2020-05-09 18:51:35 --> Total execution time: 0.7299
INFO - 2020-05-09 18:51:38 --> Config Class Initialized
INFO - 2020-05-09 18:51:38 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:38 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:38 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:38 --> URI Class Initialized
INFO - 2020-05-09 18:51:38 --> Router Class Initialized
INFO - 2020-05-09 18:51:38 --> Output Class Initialized
INFO - 2020-05-09 18:51:38 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:38 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:38 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:38 --> Loader Class Initialized
INFO - 2020-05-09 18:51:38 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:38 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:38 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:38 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:38 --> Controller Class Initialized
INFO - 2020-05-09 18:51:38 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:51:38 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:51:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:51:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:51:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_index.php
INFO - 2020-05-09 18:51:39 --> Final output sent to browser
DEBUG - 2020-05-09 18:51:39 --> Total execution time: 0.6721
INFO - 2020-05-09 18:51:42 --> Config Class Initialized
INFO - 2020-05-09 18:51:42 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:51:42 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:51:42 --> Utf8 Class Initialized
INFO - 2020-05-09 18:51:42 --> URI Class Initialized
INFO - 2020-05-09 18:51:42 --> Router Class Initialized
INFO - 2020-05-09 18:51:42 --> Output Class Initialized
INFO - 2020-05-09 18:51:42 --> Security Class Initialized
DEBUG - 2020-05-09 18:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:51:42 --> Input Class Initialized
DEBUG - 2020-05-09 18:51:42 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:51:42 --> Loader Class Initialized
INFO - 2020-05-09 18:51:42 --> Helper loaded: language_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: url_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: html_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: form_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: util_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: session_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:51:42 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:51:42 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:51:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:51:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:51:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:51:42 --> Encryption Class Initialized
INFO - 2020-05-09 18:51:42 --> Controller Class Initialized
INFO - 2020-05-09 18:51:42 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:51:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:51:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:51:42 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_insertar.php
INFO - 2020-05-09 18:51:42 --> Final output sent to browser
DEBUG - 2020-05-09 18:51:42 --> Total execution time: 0.6342
INFO - 2020-05-09 18:52:29 --> Config Class Initialized
INFO - 2020-05-09 18:52:29 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:52:29 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:52:29 --> Utf8 Class Initialized
INFO - 2020-05-09 18:52:29 --> URI Class Initialized
INFO - 2020-05-09 18:52:29 --> Router Class Initialized
INFO - 2020-05-09 18:52:29 --> Output Class Initialized
INFO - 2020-05-09 18:52:29 --> Security Class Initialized
DEBUG - 2020-05-09 18:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:52:29 --> Input Class Initialized
DEBUG - 2020-05-09 18:52:29 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:52:29 --> Loader Class Initialized
INFO - 2020-05-09 18:52:29 --> Helper loaded: language_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: url_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: html_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: form_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: util_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: session_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:52:29 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:52:29 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:52:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:52:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:52:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:52:30 --> Encryption Class Initialized
INFO - 2020-05-09 18:52:30 --> Controller Class Initialized
INFO - 2020-05-09 18:52:30 --> Form Validation Class Initialized
INFO - 2020-05-09 18:52:30 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2020-05-09 18:52:30 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:52:30 --> Upload Class Initialized
INFO - 2020-05-09 18:52:30 --> Config Class Initialized
INFO - 2020-05-09 18:52:30 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:52:30 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:52:30 --> Utf8 Class Initialized
INFO - 2020-05-09 18:52:30 --> URI Class Initialized
INFO - 2020-05-09 18:52:30 --> Router Class Initialized
INFO - 2020-05-09 18:52:30 --> Output Class Initialized
INFO - 2020-05-09 18:52:30 --> Security Class Initialized
DEBUG - 2020-05-09 18:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:52:30 --> Input Class Initialized
DEBUG - 2020-05-09 18:52:30 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:52:30 --> Loader Class Initialized
INFO - 2020-05-09 18:52:30 --> Helper loaded: language_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: url_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: html_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: form_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: util_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: session_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:52:30 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:52:30 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:52:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:52:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:52:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:52:30 --> Encryption Class Initialized
INFO - 2020-05-09 18:52:30 --> Controller Class Initialized
INFO - 2020-05-09 18:52:31 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:52:31 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:52:31 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:52:31 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:52:31 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/agentes/agentes_index.php
INFO - 2020-05-09 18:52:31 --> Final output sent to browser
DEBUG - 2020-05-09 18:52:31 --> Total execution time: 0.6943
INFO - 2020-05-09 18:52:37 --> Config Class Initialized
INFO - 2020-05-09 18:52:37 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:52:37 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:52:37 --> Utf8 Class Initialized
INFO - 2020-05-09 18:52:37 --> URI Class Initialized
INFO - 2020-05-09 18:52:37 --> Router Class Initialized
INFO - 2020-05-09 18:52:37 --> Output Class Initialized
INFO - 2020-05-09 18:52:37 --> Security Class Initialized
DEBUG - 2020-05-09 18:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:52:37 --> Input Class Initialized
DEBUG - 2020-05-09 18:52:37 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:52:37 --> Loader Class Initialized
INFO - 2020-05-09 18:52:37 --> Helper loaded: language_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: url_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: html_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: form_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: util_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: session_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:52:37 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:52:37 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:52:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:52:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:52:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:52:37 --> Encryption Class Initialized
INFO - 2020-05-09 18:52:37 --> Controller Class Initialized
INFO - 2020-05-09 18:52:37 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:52:37 --> Final output sent to browser
DEBUG - 2020-05-09 18:52:37 --> Total execution time: 0.5954
INFO - 2020-05-09 18:52:41 --> Config Class Initialized
INFO - 2020-05-09 18:52:41 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:52:41 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:52:41 --> Utf8 Class Initialized
INFO - 2020-05-09 18:52:41 --> URI Class Initialized
INFO - 2020-05-09 18:52:41 --> Router Class Initialized
INFO - 2020-05-09 18:52:41 --> Output Class Initialized
INFO - 2020-05-09 18:52:41 --> Security Class Initialized
DEBUG - 2020-05-09 18:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:52:41 --> Input Class Initialized
DEBUG - 2020-05-09 18:52:41 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:52:41 --> Loader Class Initialized
INFO - 2020-05-09 18:52:41 --> Helper loaded: language_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: url_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: html_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: form_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: util_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: session_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:52:41 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:52:41 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:52:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:52:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:52:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:52:41 --> Encryption Class Initialized
INFO - 2020-05-09 18:52:41 --> Controller Class Initialized
INFO - 2020-05-09 18:52:41 --> Model "Agentes_model" initialized
INFO - 2020-05-09 18:52:41 --> Final output sent to browser
DEBUG - 2020-05-09 18:52:41 --> Total execution time: 0.5895
INFO - 2020-05-09 18:53:17 --> Config Class Initialized
INFO - 2020-05-09 18:53:17 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:53:17 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:53:17 --> Utf8 Class Initialized
INFO - 2020-05-09 18:53:17 --> URI Class Initialized
INFO - 2020-05-09 18:53:17 --> Router Class Initialized
INFO - 2020-05-09 18:53:17 --> Output Class Initialized
INFO - 2020-05-09 18:53:17 --> Security Class Initialized
DEBUG - 2020-05-09 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:53:17 --> Input Class Initialized
DEBUG - 2020-05-09 18:53:17 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:53:17 --> Loader Class Initialized
INFO - 2020-05-09 18:53:17 --> Helper loaded: language_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: url_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: html_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: form_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: util_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: session_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:53:17 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:53:17 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:53:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:53:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:53:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:53:18 --> Encryption Class Initialized
INFO - 2020-05-09 18:53:18 --> Controller Class Initialized
INFO - 2020-05-09 18:53:18 --> Model "Usuarios_model" initialized
INFO - 2020-05-09 18:53:18 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:53:18 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:53:18 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:53:18 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/usuarios/usuarios_index.php
INFO - 2020-05-09 18:53:18 --> Final output sent to browser
DEBUG - 2020-05-09 18:53:18 --> Total execution time: 0.7796
INFO - 2020-05-09 18:53:25 --> Config Class Initialized
INFO - 2020-05-09 18:53:25 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:53:25 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:53:25 --> Utf8 Class Initialized
INFO - 2020-05-09 18:53:25 --> URI Class Initialized
INFO - 2020-05-09 18:53:25 --> Router Class Initialized
INFO - 2020-05-09 18:53:25 --> Output Class Initialized
INFO - 2020-05-09 18:53:25 --> Security Class Initialized
DEBUG - 2020-05-09 18:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:53:25 --> Input Class Initialized
DEBUG - 2020-05-09 18:53:25 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:53:25 --> Loader Class Initialized
INFO - 2020-05-09 18:53:25 --> Helper loaded: language_helper
INFO - 2020-05-09 18:53:25 --> Helper loaded: url_helper
INFO - 2020-05-09 18:53:25 --> Helper loaded: html_helper
INFO - 2020-05-09 18:53:25 --> Helper loaded: form_helper
INFO - 2020-05-09 18:53:26 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:53:26 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:53:26 --> Helper loaded: util_helper
INFO - 2020-05-09 18:53:26 --> Helper loaded: session_helper
INFO - 2020-05-09 18:53:26 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:53:26 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:53:26 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:53:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:53:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:53:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:53:26 --> Encryption Class Initialized
INFO - 2020-05-09 18:53:26 --> Controller Class Initialized
INFO - 2020-05-09 18:53:26 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:53:26 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:53:26 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:53:26 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/usuarios/usuarios_insertar.php
INFO - 2020-05-09 18:53:26 --> Final output sent to browser
DEBUG - 2020-05-09 18:53:26 --> Total execution time: 0.8042
INFO - 2020-05-09 18:53:54 --> Config Class Initialized
INFO - 2020-05-09 18:53:54 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:53:54 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:53:54 --> Utf8 Class Initialized
INFO - 2020-05-09 18:53:54 --> URI Class Initialized
INFO - 2020-05-09 18:53:54 --> Router Class Initialized
INFO - 2020-05-09 18:53:54 --> Output Class Initialized
INFO - 2020-05-09 18:53:54 --> Security Class Initialized
DEBUG - 2020-05-09 18:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:53:54 --> Input Class Initialized
DEBUG - 2020-05-09 18:53:54 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:53:54 --> Loader Class Initialized
INFO - 2020-05-09 18:53:54 --> Helper loaded: language_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: url_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: html_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: form_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: util_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: session_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:53:54 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:53:54 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:53:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:53:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:53:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:53:54 --> Encryption Class Initialized
INFO - 2020-05-09 18:53:54 --> Controller Class Initialized
INFO - 2020-05-09 18:53:54 --> Form Validation Class Initialized
INFO - 2020-05-09 18:53:54 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2020-05-09 18:53:54 --> Model "Usuarios_model" initialized
INFO - 2020-05-09 18:53:54 --> Config Class Initialized
INFO - 2020-05-09 18:53:54 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:53:54 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:53:54 --> Utf8 Class Initialized
INFO - 2020-05-09 18:53:54 --> URI Class Initialized
INFO - 2020-05-09 18:53:54 --> Router Class Initialized
INFO - 2020-05-09 18:53:55 --> Output Class Initialized
INFO - 2020-05-09 18:53:55 --> Security Class Initialized
DEBUG - 2020-05-09 18:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:53:55 --> Input Class Initialized
DEBUG - 2020-05-09 18:53:55 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:53:55 --> Loader Class Initialized
INFO - 2020-05-09 18:53:55 --> Helper loaded: language_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: url_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: html_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: form_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: util_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: session_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:53:55 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:53:55 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:53:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:53:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:53:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:53:55 --> Encryption Class Initialized
INFO - 2020-05-09 18:53:55 --> Controller Class Initialized
INFO - 2020-05-09 18:53:55 --> Model "Usuarios_model" initialized
INFO - 2020-05-09 18:53:55 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:53:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:53:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:53:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/usuarios/usuarios_index.php
INFO - 2020-05-09 18:53:55 --> Final output sent to browser
DEBUG - 2020-05-09 18:53:55 --> Total execution time: 0.6522
INFO - 2020-05-09 18:53:59 --> Config Class Initialized
INFO - 2020-05-09 18:53:59 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:53:59 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:53:59 --> Utf8 Class Initialized
INFO - 2020-05-09 18:53:59 --> URI Class Initialized
INFO - 2020-05-09 18:53:59 --> Router Class Initialized
INFO - 2020-05-09 18:53:59 --> Output Class Initialized
INFO - 2020-05-09 18:53:59 --> Security Class Initialized
DEBUG - 2020-05-09 18:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:53:59 --> Input Class Initialized
DEBUG - 2020-05-09 18:53:59 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:53:59 --> Loader Class Initialized
INFO - 2020-05-09 18:53:59 --> Helper loaded: language_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: url_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: html_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: form_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: util_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: session_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:53:59 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:53:59 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:53:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:53:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:53:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:53:59 --> Encryption Class Initialized
INFO - 2020-05-09 18:53:59 --> Controller Class Initialized
INFO - 2020-05-09 18:53:59 --> Model "Usuarios_model" initialized
INFO - 2020-05-09 18:53:59 --> Final output sent to browser
DEBUG - 2020-05-09 18:53:59 --> Total execution time: 0.6318
INFO - 2020-05-09 18:54:02 --> Config Class Initialized
INFO - 2020-05-09 18:54:02 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:54:02 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:54:02 --> Utf8 Class Initialized
INFO - 2020-05-09 18:54:02 --> URI Class Initialized
INFO - 2020-05-09 18:54:02 --> Router Class Initialized
INFO - 2020-05-09 18:54:02 --> Output Class Initialized
INFO - 2020-05-09 18:54:02 --> Security Class Initialized
DEBUG - 2020-05-09 18:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:54:03 --> Input Class Initialized
DEBUG - 2020-05-09 18:54:03 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:54:03 --> Loader Class Initialized
INFO - 2020-05-09 18:54:03 --> Helper loaded: language_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: url_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: html_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: form_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: util_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: session_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:54:03 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:54:03 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:54:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:54:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:54:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:54:03 --> Encryption Class Initialized
INFO - 2020-05-09 18:54:03 --> Controller Class Initialized
INFO - 2020-05-09 18:54:03 --> Model "Usuarios_model" initialized
INFO - 2020-05-09 18:54:03 --> Final output sent to browser
DEBUG - 2020-05-09 18:54:03 --> Total execution time: 0.6499
INFO - 2020-05-09 18:54:06 --> Config Class Initialized
INFO - 2020-05-09 18:54:06 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:54:07 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:54:07 --> Utf8 Class Initialized
INFO - 2020-05-09 18:54:07 --> URI Class Initialized
INFO - 2020-05-09 18:54:07 --> Router Class Initialized
INFO - 2020-05-09 18:54:07 --> Output Class Initialized
INFO - 2020-05-09 18:54:07 --> Security Class Initialized
DEBUG - 2020-05-09 18:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:54:07 --> Input Class Initialized
DEBUG - 2020-05-09 18:54:07 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:54:07 --> Loader Class Initialized
INFO - 2020-05-09 18:54:07 --> Helper loaded: language_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: url_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: html_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: form_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: util_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: session_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:54:07 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:54:07 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:54:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:54:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:54:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:54:07 --> Encryption Class Initialized
INFO - 2020-05-09 18:54:07 --> Controller Class Initialized
INFO - 2020-05-09 18:54:07 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:54:07 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:54:08 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:54:08 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:54:08 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 18:54:08 --> Final output sent to browser
DEBUG - 2020-05-09 18:54:08 --> Total execution time: 1.1491
INFO - 2020-05-09 18:54:10 --> Config Class Initialized
INFO - 2020-05-09 18:54:10 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:54:10 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:54:10 --> Utf8 Class Initialized
INFO - 2020-05-09 18:54:10 --> URI Class Initialized
INFO - 2020-05-09 18:54:10 --> Router Class Initialized
INFO - 2020-05-09 18:54:10 --> Output Class Initialized
INFO - 2020-05-09 18:54:10 --> Security Class Initialized
DEBUG - 2020-05-09 18:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:54:10 --> Input Class Initialized
DEBUG - 2020-05-09 18:54:10 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:54:10 --> 404 Page Not Found: Assets/admon
INFO - 2020-05-09 18:54:43 --> Config Class Initialized
INFO - 2020-05-09 18:54:43 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:54:43 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:54:43 --> Utf8 Class Initialized
INFO - 2020-05-09 18:54:43 --> URI Class Initialized
INFO - 2020-05-09 18:54:43 --> Router Class Initialized
INFO - 2020-05-09 18:54:43 --> Output Class Initialized
INFO - 2020-05-09 18:54:43 --> Security Class Initialized
DEBUG - 2020-05-09 18:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:54:43 --> Input Class Initialized
DEBUG - 2020-05-09 18:54:43 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:54:43 --> Loader Class Initialized
INFO - 2020-05-09 18:54:43 --> Helper loaded: language_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: url_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: html_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: form_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: util_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: session_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:54:43 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:54:43 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:54:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:54:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:54:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:54:43 --> Encryption Class Initialized
INFO - 2020-05-09 18:54:43 --> Controller Class Initialized
INFO - 2020-05-09 18:54:43 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:54:43 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:54:43 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:54:43 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:54:44 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:54:44 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_editar.php
INFO - 2020-05-09 18:54:44 --> Final output sent to browser
DEBUG - 2020-05-09 18:54:44 --> Total execution time: 0.9482
INFO - 2020-05-09 18:56:46 --> Config Class Initialized
INFO - 2020-05-09 18:56:46 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:56:46 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:56:46 --> Utf8 Class Initialized
INFO - 2020-05-09 18:56:46 --> URI Class Initialized
INFO - 2020-05-09 18:56:46 --> Router Class Initialized
INFO - 2020-05-09 18:56:46 --> Output Class Initialized
INFO - 2020-05-09 18:56:46 --> Security Class Initialized
DEBUG - 2020-05-09 18:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:56:46 --> Input Class Initialized
DEBUG - 2020-05-09 18:56:46 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:56:46 --> Loader Class Initialized
INFO - 2020-05-09 18:56:46 --> Helper loaded: language_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: url_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: html_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: form_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: util_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: session_helper
INFO - 2020-05-09 18:56:46 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:56:47 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:56:47 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:56:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:56:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:56:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:56:47 --> Encryption Class Initialized
INFO - 2020-05-09 18:56:47 --> Controller Class Initialized
INFO - 2020-05-09 18:56:47 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:56:47 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:56:47 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:56:47 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:56:47 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 18:56:47 --> Final output sent to browser
DEBUG - 2020-05-09 18:56:47 --> Total execution time: 0.8677
INFO - 2020-05-09 18:56:48 --> Config Class Initialized
INFO - 2020-05-09 18:56:48 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:56:48 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:56:48 --> Utf8 Class Initialized
INFO - 2020-05-09 18:56:48 --> URI Class Initialized
INFO - 2020-05-09 18:56:48 --> Router Class Initialized
INFO - 2020-05-09 18:56:48 --> Output Class Initialized
INFO - 2020-05-09 18:56:48 --> Security Class Initialized
DEBUG - 2020-05-09 18:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:56:48 --> Input Class Initialized
DEBUG - 2020-05-09 18:56:49 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:56:49 --> 404 Page Not Found: Assets/admon
INFO - 2020-05-09 18:57:49 --> Config Class Initialized
INFO - 2020-05-09 18:57:49 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:57:49 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:57:49 --> Utf8 Class Initialized
INFO - 2020-05-09 18:57:49 --> URI Class Initialized
INFO - 2020-05-09 18:57:49 --> Router Class Initialized
INFO - 2020-05-09 18:57:49 --> Output Class Initialized
INFO - 2020-05-09 18:57:49 --> Security Class Initialized
DEBUG - 2020-05-09 18:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:57:49 --> Input Class Initialized
DEBUG - 2020-05-09 18:57:49 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:57:49 --> Loader Class Initialized
INFO - 2020-05-09 18:57:49 --> Helper loaded: language_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: url_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: html_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: form_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: util_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: session_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:57:50 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:57:50 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:57:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:57:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:57:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:57:50 --> Encryption Class Initialized
INFO - 2020-05-09 18:57:50 --> Controller Class Initialized
INFO - 2020-05-09 18:57:50 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:57:50 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:57:50 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:57:50 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:57:50 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:57:50 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_insertar.php
INFO - 2020-05-09 18:57:50 --> Final output sent to browser
DEBUG - 2020-05-09 18:57:50 --> Total execution time: 0.9557
INFO - 2020-05-09 18:57:51 --> Config Class Initialized
INFO - 2020-05-09 18:57:51 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:57:52 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:57:52 --> Utf8 Class Initialized
INFO - 2020-05-09 18:57:52 --> URI Class Initialized
INFO - 2020-05-09 18:57:52 --> Router Class Initialized
INFO - 2020-05-09 18:57:52 --> Output Class Initialized
INFO - 2020-05-09 18:57:52 --> Security Class Initialized
DEBUG - 2020-05-09 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:57:52 --> Input Class Initialized
DEBUG - 2020-05-09 18:57:52 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:57:52 --> Loader Class Initialized
INFO - 2020-05-09 18:57:52 --> Helper loaded: language_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: url_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: html_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: form_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: util_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: session_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:57:52 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:57:52 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:57:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:57:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:57:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:57:52 --> Encryption Class Initialized
INFO - 2020-05-09 18:57:52 --> Controller Class Initialized
INFO - 2020-05-09 18:57:52 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:57:52 --> Final output sent to browser
DEBUG - 2020-05-09 18:57:52 --> Total execution time: 1.1820
INFO - 2020-05-09 18:57:54 --> Config Class Initialized
INFO - 2020-05-09 18:57:54 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:57:54 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:57:54 --> Utf8 Class Initialized
INFO - 2020-05-09 18:57:54 --> URI Class Initialized
INFO - 2020-05-09 18:57:54 --> Router Class Initialized
INFO - 2020-05-09 18:57:54 --> Output Class Initialized
INFO - 2020-05-09 18:57:54 --> Security Class Initialized
DEBUG - 2020-05-09 18:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:57:54 --> Input Class Initialized
DEBUG - 2020-05-09 18:57:54 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:57:54 --> Loader Class Initialized
INFO - 2020-05-09 18:57:54 --> Helper loaded: language_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: url_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: html_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: form_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: util_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: session_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:57:54 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:57:54 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:57:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:57:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:57:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:57:54 --> Encryption Class Initialized
INFO - 2020-05-09 18:57:54 --> Controller Class Initialized
INFO - 2020-05-09 18:57:54 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:57:55 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:57:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:57:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:57:55 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 18:57:55 --> Final output sent to browser
DEBUG - 2020-05-09 18:57:55 --> Total execution time: 0.9178
INFO - 2020-05-09 18:57:56 --> Config Class Initialized
INFO - 2020-05-09 18:57:56 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:57:56 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:57:56 --> Utf8 Class Initialized
INFO - 2020-05-09 18:57:56 --> URI Class Initialized
INFO - 2020-05-09 18:57:56 --> Router Class Initialized
INFO - 2020-05-09 18:57:56 --> Output Class Initialized
INFO - 2020-05-09 18:57:56 --> Security Class Initialized
DEBUG - 2020-05-09 18:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:57:56 --> Input Class Initialized
DEBUG - 2020-05-09 18:57:56 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:57:56 --> 404 Page Not Found: Assets/admon
INFO - 2020-05-09 18:57:58 --> Config Class Initialized
INFO - 2020-05-09 18:57:58 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:57:58 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:57:58 --> Utf8 Class Initialized
INFO - 2020-05-09 18:57:58 --> URI Class Initialized
INFO - 2020-05-09 18:57:58 --> Router Class Initialized
INFO - 2020-05-09 18:57:58 --> Output Class Initialized
INFO - 2020-05-09 18:57:58 --> Security Class Initialized
DEBUG - 2020-05-09 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:57:58 --> Input Class Initialized
DEBUG - 2020-05-09 18:57:58 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:57:58 --> Loader Class Initialized
INFO - 2020-05-09 18:57:58 --> Helper loaded: language_helper
INFO - 2020-05-09 18:57:58 --> Helper loaded: url_helper
INFO - 2020-05-09 18:57:58 --> Helper loaded: html_helper
INFO - 2020-05-09 18:57:58 --> Helper loaded: form_helper
INFO - 2020-05-09 18:57:58 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:57:58 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:57:59 --> Helper loaded: util_helper
INFO - 2020-05-09 18:57:59 --> Helper loaded: session_helper
INFO - 2020-05-09 18:57:59 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:57:59 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:57:59 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:57:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:57:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:57:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:57:59 --> Encryption Class Initialized
INFO - 2020-05-09 18:57:59 --> Controller Class Initialized
INFO - 2020-05-09 18:57:59 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:57:59 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:57:59 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:57:59 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:57:59 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:57:59 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_editar.php
INFO - 2020-05-09 18:57:59 --> Final output sent to browser
DEBUG - 2020-05-09 18:57:59 --> Total execution time: 0.7943
INFO - 2020-05-09 18:58:10 --> Config Class Initialized
INFO - 2020-05-09 18:58:10 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:58:10 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:58:10 --> Utf8 Class Initialized
INFO - 2020-05-09 18:58:10 --> URI Class Initialized
INFO - 2020-05-09 18:58:10 --> Router Class Initialized
INFO - 2020-05-09 18:58:10 --> Output Class Initialized
INFO - 2020-05-09 18:58:10 --> Security Class Initialized
DEBUG - 2020-05-09 18:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:58:10 --> Input Class Initialized
DEBUG - 2020-05-09 18:58:10 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:58:10 --> Loader Class Initialized
INFO - 2020-05-09 18:58:10 --> Helper loaded: language_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: url_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: html_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: form_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: util_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: session_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:58:10 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:58:10 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:58:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:58:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:58:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:58:10 --> Encryption Class Initialized
INFO - 2020-05-09 18:58:10 --> Controller Class Initialized
INFO - 2020-05-09 18:58:10 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:58:11 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:58:11 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:58:11 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:58:11 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 18:58:11 --> Final output sent to browser
DEBUG - 2020-05-09 18:58:11 --> Total execution time: 0.9862
INFO - 2020-05-09 18:58:12 --> Config Class Initialized
INFO - 2020-05-09 18:58:12 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:58:12 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:58:12 --> Utf8 Class Initialized
INFO - 2020-05-09 18:58:12 --> URI Class Initialized
INFO - 2020-05-09 18:58:12 --> Router Class Initialized
INFO - 2020-05-09 18:58:12 --> Output Class Initialized
INFO - 2020-05-09 18:58:12 --> Security Class Initialized
DEBUG - 2020-05-09 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:58:13 --> Input Class Initialized
DEBUG - 2020-05-09 18:58:13 --> ---- Loaded Language: spanish ----
ERROR - 2020-05-09 18:58:13 --> 404 Page Not Found: Assets/admon
INFO - 2020-05-09 18:59:18 --> Config Class Initialized
INFO - 2020-05-09 18:59:18 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:59:18 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:59:18 --> Utf8 Class Initialized
INFO - 2020-05-09 18:59:18 --> URI Class Initialized
INFO - 2020-05-09 18:59:18 --> Router Class Initialized
INFO - 2020-05-09 18:59:19 --> Output Class Initialized
INFO - 2020-05-09 18:59:19 --> Security Class Initialized
DEBUG - 2020-05-09 18:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:59:19 --> Input Class Initialized
DEBUG - 2020-05-09 18:59:19 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:59:19 --> Loader Class Initialized
INFO - 2020-05-09 18:59:19 --> Helper loaded: language_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: url_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: html_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: form_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: util_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: session_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:59:19 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:59:19 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:59:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:59:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:59:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:59:19 --> Encryption Class Initialized
INFO - 2020-05-09 18:59:19 --> Controller Class Initialized
INFO - 2020-05-09 18:59:19 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:59:19 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 18:59:19 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 18:59:19 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 18:59:19 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 18:59:19 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_insertar.php
INFO - 2020-05-09 18:59:19 --> Final output sent to browser
DEBUG - 2020-05-09 18:59:19 --> Total execution time: 0.7927
INFO - 2020-05-09 18:59:20 --> Config Class Initialized
INFO - 2020-05-09 18:59:20 --> Hooks Class Initialized
DEBUG - 2020-05-09 18:59:20 --> UTF-8 Support Enabled
INFO - 2020-05-09 18:59:20 --> Utf8 Class Initialized
INFO - 2020-05-09 18:59:20 --> URI Class Initialized
INFO - 2020-05-09 18:59:20 --> Router Class Initialized
INFO - 2020-05-09 18:59:20 --> Output Class Initialized
INFO - 2020-05-09 18:59:20 --> Security Class Initialized
DEBUG - 2020-05-09 18:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 18:59:20 --> Input Class Initialized
DEBUG - 2020-05-09 18:59:20 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 18:59:21 --> Loader Class Initialized
INFO - 2020-05-09 18:59:21 --> Helper loaded: language_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: url_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: html_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: form_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: uri_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: alert_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: util_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: session_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: menu_helper
INFO - 2020-05-09 18:59:21 --> Helper loaded: buscador_helper
INFO - 2020-05-09 18:59:21 --> Database Driver Class Initialized
DEBUG - 2020-05-09 18:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 18:59:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 18:59:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 18:59:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 18:59:21 --> Encryption Class Initialized
INFO - 2020-05-09 18:59:21 --> Controller Class Initialized
INFO - 2020-05-09 18:59:21 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 18:59:21 --> Final output sent to browser
DEBUG - 2020-05-09 18:59:21 --> Total execution time: 1.1816
INFO - 2020-05-09 19:00:11 --> Config Class Initialized
INFO - 2020-05-09 19:00:11 --> Hooks Class Initialized
DEBUG - 2020-05-09 19:00:11 --> UTF-8 Support Enabled
INFO - 2020-05-09 19:00:11 --> Utf8 Class Initialized
INFO - 2020-05-09 19:00:11 --> URI Class Initialized
INFO - 2020-05-09 19:00:11 --> Router Class Initialized
INFO - 2020-05-09 19:00:11 --> Output Class Initialized
INFO - 2020-05-09 19:00:11 --> Security Class Initialized
DEBUG - 2020-05-09 19:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 19:00:11 --> Input Class Initialized
DEBUG - 2020-05-09 19:00:11 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 19:00:11 --> Loader Class Initialized
INFO - 2020-05-09 19:00:11 --> Helper loaded: language_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: url_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: html_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: form_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: uri_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: alert_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: util_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: session_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: menu_helper
INFO - 2020-05-09 19:00:11 --> Helper loaded: buscador_helper
INFO - 2020-05-09 19:00:11 --> Database Driver Class Initialized
DEBUG - 2020-05-09 19:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 19:00:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 19:00:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 19:00:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 19:00:11 --> Encryption Class Initialized
INFO - 2020-05-09 19:00:11 --> Controller Class Initialized
INFO - 2020-05-09 19:00:11 --> Model "Tipo_propiedad_model" initialized
INFO - 2020-05-09 19:00:11 --> Final output sent to browser
DEBUG - 2020-05-09 19:00:11 --> Total execution time: 0.6326
INFO - 2020-05-09 19:00:30 --> Config Class Initialized
INFO - 2020-05-09 19:00:30 --> Hooks Class Initialized
DEBUG - 2020-05-09 19:00:30 --> UTF-8 Support Enabled
INFO - 2020-05-09 19:00:30 --> Utf8 Class Initialized
INFO - 2020-05-09 19:00:30 --> URI Class Initialized
INFO - 2020-05-09 19:00:30 --> Router Class Initialized
INFO - 2020-05-09 19:00:31 --> Output Class Initialized
INFO - 2020-05-09 19:00:31 --> Security Class Initialized
DEBUG - 2020-05-09 19:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 19:00:31 --> Input Class Initialized
DEBUG - 2020-05-09 19:00:31 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 19:00:31 --> Loader Class Initialized
INFO - 2020-05-09 19:00:31 --> Helper loaded: language_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: url_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: html_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: form_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: uri_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: alert_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: util_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: session_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: menu_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: buscador_helper
INFO - 2020-05-09 19:00:31 --> Database Driver Class Initialized
DEBUG - 2020-05-09 19:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 19:00:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 19:00:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 19:00:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 19:00:31 --> Encryption Class Initialized
INFO - 2020-05-09 19:00:31 --> Controller Class Initialized
INFO - 2020-05-09 19:00:31 --> Form Validation Class Initialized
INFO - 2020-05-09 19:00:31 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2020-05-09 19:00:31 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 19:00:31 --> Model "Estatus_propiedades_model" initialized
INFO - 2020-05-09 19:00:31 --> Upload Class Initialized
DEBUG - 2020-05-09 19:00:31 --> Si sube imagen con nombre: abr_promo01.3.jpg
INFO - 2020-05-09 19:00:31 --> Config Class Initialized
INFO - 2020-05-09 19:00:31 --> Hooks Class Initialized
DEBUG - 2020-05-09 19:00:31 --> UTF-8 Support Enabled
INFO - 2020-05-09 19:00:31 --> Utf8 Class Initialized
INFO - 2020-05-09 19:00:31 --> URI Class Initialized
INFO - 2020-05-09 19:00:31 --> Router Class Initialized
INFO - 2020-05-09 19:00:31 --> Output Class Initialized
INFO - 2020-05-09 19:00:31 --> Security Class Initialized
DEBUG - 2020-05-09 19:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 19:00:31 --> Input Class Initialized
DEBUG - 2020-05-09 19:00:31 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 19:00:31 --> Loader Class Initialized
INFO - 2020-05-09 19:00:31 --> Helper loaded: language_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: url_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: html_helper
INFO - 2020-05-09 19:00:31 --> Helper loaded: form_helper
INFO - 2020-05-09 19:00:32 --> Helper loaded: uri_helper
INFO - 2020-05-09 19:00:32 --> Helper loaded: alert_helper
INFO - 2020-05-09 19:00:32 --> Helper loaded: util_helper
INFO - 2020-05-09 19:00:32 --> Helper loaded: session_helper
INFO - 2020-05-09 19:00:32 --> Helper loaded: menu_helper
INFO - 2020-05-09 19:00:32 --> Helper loaded: buscador_helper
INFO - 2020-05-09 19:00:32 --> Database Driver Class Initialized
DEBUG - 2020-05-09 19:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 19:00:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 19:00:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 19:00:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 19:00:32 --> Encryption Class Initialized
INFO - 2020-05-09 19:00:32 --> Controller Class Initialized
INFO - 2020-05-09 19:00:32 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 19:00:32 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 19:00:32 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_app_1.php
INFO - 2020-05-09 19:00:32 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_app_1.php
INFO - 2020-05-09 19:00:32 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\admon/propiedades/propiedades_index.php
INFO - 2020-05-09 19:00:32 --> Final output sent to browser
DEBUG - 2020-05-09 19:00:32 --> Total execution time: 0.8742
INFO - 2020-05-09 19:00:38 --> Config Class Initialized
INFO - 2020-05-09 19:00:38 --> Hooks Class Initialized
DEBUG - 2020-05-09 19:00:38 --> UTF-8 Support Enabled
INFO - 2020-05-09 19:00:38 --> Utf8 Class Initialized
INFO - 2020-05-09 19:00:38 --> URI Class Initialized
DEBUG - 2020-05-09 19:00:38 --> No URI present. Default controller set.
INFO - 2020-05-09 19:00:38 --> Router Class Initialized
INFO - 2020-05-09 19:00:38 --> Output Class Initialized
INFO - 2020-05-09 19:00:38 --> Security Class Initialized
DEBUG - 2020-05-09 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-09 19:00:38 --> Input Class Initialized
DEBUG - 2020-05-09 19:00:38 --> ---- Loaded Language: spanish ----
INFO - 2020-05-09 19:00:38 --> Loader Class Initialized
INFO - 2020-05-09 19:00:38 --> Helper loaded: language_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: url_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: html_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: form_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: uri_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: alert_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: util_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: session_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: menu_helper
INFO - 2020-05-09 19:00:38 --> Helper loaded: buscador_helper
INFO - 2020-05-09 19:00:38 --> Database Driver Class Initialized
DEBUG - 2020-05-09 19:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-05-09 19:00:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-09 19:00:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-05-09 19:00:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-05-09 19:00:38 --> Encryption Class Initialized
INFO - 2020-05-09 19:00:38 --> Controller Class Initialized
INFO - 2020-05-09 19:00:38 --> Model "Propiedades_model" initialized
INFO - 2020-05-09 19:00:38 --> Model "Agentes_model" initialized
INFO - 2020-05-09 19:00:38 --> Language file loaded: language/spanish/inicio/inicio_index_lang.php
INFO - 2020-05-09 19:00:39 --> Language file loaded: language/spanish/menus/menu_web_1_lang.php
INFO - 2020-05-09 19:00:39 --> Model "Tipo_propiedad_model" initialized
ERROR - 2020-05-09 19:00:39 --> Could not find the language line "buscar"
INFO - 2020-05-09 19:00:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\menus/menu_web_1.php
ERROR - 2020-05-09 19:00:39 --> Could not find the language line "Venta"
ERROR - 2020-05-09 19:00:39 --> Could not find the language line "Venta"
DEBUG - 2020-05-09 19:00:39 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 19:00:39 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 19:00:39 --> Language file loaded: language/spanish/footers/footers_web_1_lang.php
DEBUG - 2020-05-09 19:00:39 --> Filtros_busqueda class already loaded. Second attempt ignored.
DEBUG - 2020-05-09 19:00:39 --> Catalogos class already loaded. Second attempt ignored.
INFO - 2020-05-09 19:00:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\footers/footers_web_1.php
INFO - 2020-05-09 19:00:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/g_analytics.php
INFO - 2020-05-09 19:00:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\elementos_extras/chat_tawk.php
INFO - 2020-05-09 19:00:39 --> File loaded: C:\xampp\htdocs\inmobiliaria\application\views\inicio/inicio_index.php
INFO - 2020-05-09 19:00:39 --> Final output sent to browser
DEBUG - 2020-05-09 19:00:39 --> Total execution time: 1.3374
