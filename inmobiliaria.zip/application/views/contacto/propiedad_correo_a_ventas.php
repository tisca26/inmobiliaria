<h1>Nuevo prospecto</h1>
<p><strong>Nombre:</strong> <?php echo $nombre; ?></p>
<p><strong>Email:</strong> <?php echo $email; ?></p>
<p><strong>Teléfono:</strong> <?php echo $telefono; ?></p>
<p><strong>Mensaje:</strong> <?php echo $mensaje; ?></p>
<p><strong>Propiedad de su interes:</strong> <a href="<?php echo $propiedad_url; ?>" target="_blank">Clic aquí</a></p>