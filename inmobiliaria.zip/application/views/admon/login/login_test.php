<?php
echo $usr . ' - ' . $pass;

echo " Y EL LOGIN ES: $log";