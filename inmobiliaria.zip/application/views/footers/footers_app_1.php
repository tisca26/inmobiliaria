<div class="footer">
    <div class="pull-right">
        <strong><?php echo EMPRESA_NOMBRE; ?></strong> App.
    </div>
    <div>
        <strong>Copyright</strong> <?php echo EMPRESA_NOMBRE; ?> &copy; 2017
    </div>
</div>