
<pre><?php print_r($datos); ?></pre>