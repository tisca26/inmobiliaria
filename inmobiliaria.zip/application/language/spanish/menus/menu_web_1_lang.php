<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['menu_inicio'] = 'Inicio';
$lang['menu_propiedades'] = 'Propiedades';
$lang['menu_acerca'] = 'Acerca';
$lang['menu_agentes'] = 'Agentes';
$lang['menu_nosotros'] = 'Nosotros';
$lang['menu_contacto'] = 'Contacto';
$lang['menu_buscar'] = 'Buscar';

$lang['buscador_tipo_propiedad'] = 'Tipo propiedad';
$lang['buscador_estado'] = 'Ubicación';
$lang['buscador_cuartos'] = 'Cuartos';
$lang['buscador_precio_min'] = 'Precio mínimo';
$lang['buscador_precio_max'] = 'Precio máximo';

$lang['Casa'] = 'Casa';
$lang['Departamento'] = 'Departamento';
$lang['Pent - House'] = 'Pent - House';
$lang['Edificio'] = 'Edificio';