<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['footer_tel'] = 'Tel';
$lang['footer_email'] = 'Email';
$lang['footer_propiedades'] = 'Propiedades';
$lang['footer_en_renta'] = 'En Renta';
$lang['footer_en_venta'] = 'En Venta';
$lang['footer_agentes'] = 'Agentes';
$lang['footer_quienes_somos'] = 'Quienes Somos';
$lang['footer_contacto'] = 'Contacto';

$lang['footer_links'] = 'Links';
$lang['footer_nosotros'] = 'Nosotros';

$lang['footer_redes_sociales'] = 'Nuestras redes sociales';
$lang['footer_facebook'] = 'Facebook';
$lang['footer_twitter'] = 'Twitter';
$lang['footer_espere'] = 'Por favor espere...';

$lang['footer_copyright'] = '© Copyright 2017. Todos los derechos reservados.';