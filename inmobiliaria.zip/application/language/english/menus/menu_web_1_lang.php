<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['menu_inicio'] = 'Home';
$lang['menu_propiedades'] = 'Properties';
$lang['menu_acerca'] = 'About';
$lang['menu_agentes'] = 'Agents';
$lang['menu_nosotros'] = 'Who We Are';
$lang['menu_contacto'] = 'Contact';
$lang['menu_buscar'] = 'Search';

$lang['buscador_tipo_propiedad'] = 'Property Type';
$lang['buscador_estado'] = 'Location';
$lang['buscador_cuartos'] = 'Beds';
$lang['buscador_precio_min'] = 'Min price';
$lang['buscador_precio_max'] = 'Max price';

$lang['Casa'] = 'House';
$lang['Departamento'] = 'Apartment';
$lang['Pent - House'] = 'Pent - House';
$lang['Edificio'] = 'Building';