<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['footer_tel'] = 'P';
$lang['footer_email'] = 'Email';
$lang['footer_propiedades'] = 'Properties';
$lang['footer_en_renta'] = 'In Rent';
$lang['footer_en_venta'] = 'In Sale';
$lang['footer_agentes'] = 'Agents';
$lang['footer_quienes_somos'] = 'About Us';
$lang['footer_contacto'] = 'Contact';

$lang['footer_links'] = 'Links';
$lang['footer_nosotros'] = 'Us';

$lang['footer_redes_sociales'] = 'Social Media';
$lang['footer_facebook'] = 'Facebook';
$lang['footer_twitter'] = 'Twitter';
$lang['footer_espere'] = 'Wait please...';

$lang['Casa'] = 'House';
$lang['Departamento'] = 'Apartment';
$lang['Pent - House'] = 'Pent - House';
$lang['Edificio'] = 'Building';

$lang['footer_copyright'] = '© Copyright 2017. All rights reserved.';